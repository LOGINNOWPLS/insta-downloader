import os
import re
import uuid
import threading
import time
import sqlite3
from functools import wraps
from datetime import datetime

from flask import (
    Flask, render_template, request, jsonify, send_from_directory,
    abort, session, redirect, url_for
)
import yt_dlp

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-in-production")

DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads")
DB_PATH = os.path.join(os.path.dirname(__file__), "app.db")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "changeme123")

JOBS = {}
JOB_LOCK = threading.Lock()

INSTAGRAM_URL_RE = re.compile(
    r"^https?://(www\.)?instagram\.com/(p|reel|tv)/[A-Za-z0-9_\-]+/?.*$"
)


# ---------- Database ----------

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS downloads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id TEXT,
            url TEXT,
            title TEXT,
            status TEXT,
            error TEXT,
            ip TEXT,
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()


def log_download(job_id, url, title, status, error, ip):
    conn = get_db()
    conn.execute(
        "INSERT INTO downloads (job_id, url, title, status, error, ip, created_at) VALUES (?,?,?,?,?,?,?)",
        (job_id, url, title, status, error, ip, datetime.utcnow().isoformat())
    )
    conn.commit()
    conn.close()


# ---------- Helpers ----------

def is_valid_instagram_url(url: str) -> bool:
    return bool(INSTAGRAM_URL_RE.match(url.strip()))


def cleanup_old_files(max_age_seconds=3600):
    now = time.time()
    for fname in os.listdir(DOWNLOAD_DIR):
        fpath = os.path.join(DOWNLOAD_DIR, fname)
        try:
            if os.path.isfile(fpath) and now - os.path.getmtime(fpath) > max_age_seconds:
                os.remove(fpath)
        except OSError:
            pass


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return wrapper


def run_download(job_id: str, url: str, ip: str):
    cleanup_old_files()
    out_template = os.path.join(DOWNLOAD_DIR, f"{job_id}.%(ext)s")

    ydl_opts = {
        "outtmpl": out_template,
        "format": "mp4/best",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        # "cookiefile": "cookies.txt",  # needed for private/age-restricted content
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            filename = os.path.basename(ydl.prepare_filename(info))
            title = info.get("title") or "instagram_video"

        with JOB_LOCK:
            JOBS[job_id] = {"status": "done", "filename": filename, "title": title, "error": None}
        log_download(job_id, url, title, "done", None, ip)
    except Exception as e:
        with JOB_LOCK:
            JOBS[job_id] = {"status": "error", "filename": None, "title": None, "error": str(e)}
        log_download(job_id, url, None, "error", str(e), ip)


# ---------- Public routes ----------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/start", methods=["POST"])
def start_download():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)

    if not url:
        return jsonify({"error": "Please provide an Instagram URL."}), 400
    if not is_valid_instagram_url(url):
        return jsonify({"error": "That doesn't look like a valid Instagram post/reel URL."}), 400

    job_id = uuid.uuid4().hex
    with JOB_LOCK:
        JOBS[job_id] = {"status": "processing", "filename": None, "title": None, "error": None}

    thread = threading.Thread(target=run_download, args=(job_id, url, ip), daemon=True)
    thread.start()

    return jsonify({"job_id": job_id})


@app.route("/api/status/<job_id>")
def status(job_id):
    with JOB_LOCK:
        job = JOBS.get(job_id)
    if not job:
        return jsonify({"error": "Unknown job id."}), 404
    return jsonify(job)


@app.route("/download/<job_id>")
def download_file(job_id):
    with JOB_LOCK:
        job = JOBS.get(job_id)
    if not job or job["status"] != "done" or not job["filename"]:
        abort(404)
    return send_from_directory(
        DOWNLOAD_DIR, job["filename"], as_attachment=True,
        download_name=f"{job['title'][:60]}.mp4",
    )


# ---------- Admin routes ----------

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    error = None
    if request.method == "POST":
        u = request.form.get("username", "")
        p = request.form.get("password", "")
        if u == ADMIN_USER and p == ADMIN_PASS:
            session["is_admin"] = True
            return redirect(url_for("admin_dashboard"))
        error = "Invalid username or password."
    return render_template("admin_login.html", error=error)


@app.route("/admin/logout")
def admin_logout():
    session.pop("is_admin", None)
    return redirect(url_for("admin_login"))


@app.route("/admin")
@login_required
def admin_dashboard():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) c FROM downloads").fetchone()["c"]
    done = conn.execute("SELECT COUNT(*) c FROM downloads WHERE status='done'").fetchone()["c"]
    failed = conn.execute("SELECT COUNT(*) c FROM downloads WHERE status='error'").fetchone()["c"]
    recent = conn.execute("SELECT * FROM downloads ORDER BY id DESC LIMIT 50").fetchall()
    conn.close()

    storage_bytes = sum(
        os.path.getsize(os.path.join(DOWNLOAD_DIR, f))
        for f in os.listdir(DOWNLOAD_DIR) if os.path.isfile(os.path.join(DOWNLOAD_DIR, f))
    )
    storage_mb = round(storage_bytes / (1024 * 1024), 2)

    return render_template(
        "admin_dashboard.html",
        total=total, done=done, failed=failed,
        recent=recent, storage_mb=storage_mb
    )


@app.route("/admin/clear-files", methods=["POST"])
@login_required
def admin_clear_files():
    for f in os.listdir(DOWNLOAD_DIR):
        fpath = os.path.join(DOWNLOAD_DIR, f)
        if os.path.isfile(fpath):
            os.remove(fpath)
    return redirect(url_for("admin_dashboard"))


init_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(debug=False, host="0.0.0.0", port=port)
