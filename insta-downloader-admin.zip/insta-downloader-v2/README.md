# Instagram Video Downloader — Hosted Version with Admin Panel

This is the upgraded version: it includes an **admin panel** (login, stats,
download history, "clear files" button) and is set up to be deployed to a
free online host so people can use it from a real URL — no local setup needed
after deployment.

## What's new vs the basic version
- `/admin/login` — password-protected admin login
- `/admin` — dashboard with total/successful/failed request counts, storage used,
  and a table of the last 50 download attempts (URL, title, status, IP, time)
- "Clear downloaded files" button to wipe the server's disk
- Every download attempt is logged to a local SQLite database (`app.db`)
- Ready-made `render.yaml` for one-click deploy to Render.com's free tier

## Deploying it online (Render — free tier, ~10 minutes)

1. **Create a GitHub repo** and push this folder to it (or use GitHub's
   "upload files" web UI if you don't know git yet — just drag the files in).
2. Go to **render.com**, sign up (free), click **New +** → **Blueprint**.
3. Connect your GitHub repo. Render will detect `render.yaml` automatically
   and set everything up.
4. When prompted, set the **ADMIN_PASS** environment variable to a real
   password you choose (this is hidden — Render will ask you for it during
   setup since `render.yaml` marks it `sync: false`).
5. Click **Apply** / **Deploy**. Wait 2-3 minutes for the build.
6. You'll get a live URL like `https://insta-downloader-xxxx.onrender.com`
   — that's your public app. Share that link with anyone.
7. Your admin panel is at `https://insta-downloader-xxxx.onrender.com/admin`
   — log in with username `admin` and the password you set.

**Free tier note:** Render's free web services "sleep" after 15 minutes of
no traffic and take ~30-60 seconds to wake up on the next visit. That's
normal on the free plan — upgrading to a paid instance keeps it always-on.

## Alternative hosts
- **Railway.app** — similar process, also has a free trial tier.
- **PythonAnywhere** — good for beginners, has a free tier, slightly
  different setup (no `render.yaml`, you configure via their web UI).
- **Fly.io** — free allowance, more technical setup (Dockerfile-based).

## Important
- Change `ADMIN_PASS` from the default immediately — don't leave it as
  `changeme123`.
- Only download content you have the right to (your own posts, or public
  content for personal use) — redistributing others' copyrighted videos can
  violate copyright law and Instagram's Terms of Service.
- Instagram may rate-limit or block server IPs that make too many requests —
  if downloads start failing after heavy use, that's usually why.
